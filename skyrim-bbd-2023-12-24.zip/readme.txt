﻿=== Skyrim BBD Cursor Set ===

By: nathblabird (http://www.rw-designer.com/user/116003) nathblabird@gmail.com

Download: http://www.rw-designer.com/cursor-set/skyrim-bbd-2023-12-24

Author's description:

=== _SKYRIM_BBD_2023.12.24 ===

By: Nathan Blackbird (http://www.rw-designer.com/user/116003) nathblabird@gmail.com

Download: Google Drive link set with installation file 

https://drive.google.com/file/d/1EKVDUd5N4kVHFQCi_qPnHxmnBtjw65Kz/view?usp=drivesdk

Author\'s description:

Cursor set 32x32 48x48 64x64 from The Elder Scrolls V Skyrim.
Not a \"pixel accurate\" yet still good looking.
Original decompiled assets used.
Some pointers under construction. They are marked in \"install.inf\".
Feel free to ask and suggest.
Peace;)

===

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.

How to install?
1. Right click \"install.inf\" and select \"Install\" to import the mouse pointer scheme
2. Change mouse pointer scheme to \"_SKYRIM_BBD_2023.12.24\" in \"Mouse Properties\" and click \"Apply\"
3. Enjoy..

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.